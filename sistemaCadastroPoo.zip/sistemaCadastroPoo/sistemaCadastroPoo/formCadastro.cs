﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sistemaCadastroPoo
{
    public partial class formCadastro : Form
    {

        private Form telaCad;

        public formCadastro(Form pagina)
        {
            InitializeComponent();
            telaCad = pagina;
        }

        private void cadastro_Load(object sender, EventArgs e)
        {

            ConexaoDB conexaoDB = new ConexaoDB();



        }

        private void lblSenha_Click(object sender, EventArgs e)
        {

        }

        private void btnCadastro_Click(object sender, EventArgs e)
        {

            try
            {

                if (!txtNome.Text.Equals("") && !txtEmail.Text.Equals("") && !txtSenha.Text.Equals(""))
                {

                    Usuarios usuario = new Usuarios();

                    usuario.Nome = txtNome.Text;
                    usuario.Email = txtEmail.Text;
                    usuario.Senha = txtSenha.Text;


                    if (Usuarios.verificarEmail(txtEmail.Text))
                    {

                        if (usuario.cadastrarUsuario())
                        {
                            MessageBox.Show("Cadastro realizado!");
                        }
                        else
                        {

                        }

                    }
                    else
                    {

                        MessageBox.Show("Email inválido!");

                    }

                }
                else
                {

                    MessageBox.Show("Preencha os campos!");

                }

            }
            catch (Exception ex)
            {

                MessageBox.Show("Erro ao cadastrar usuário: " + ex.Message);

            }

        }

        private void linkLogin_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

            formCadastro cad = this;
            login log = new login(this);


            cad.Hide();

            log.Show();


        }

        private void formCadastro_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }
    }
}

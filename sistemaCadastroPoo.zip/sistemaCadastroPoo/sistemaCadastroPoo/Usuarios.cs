﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Security.Cryptography;
using MySql.Data.MySqlClient;

namespace sistemaCadastroPoo
{
    public class Usuarios
    {


        private int id;
        private string nome;
        private string email;
        private string senha;



        public int Id
        {

            get { return id; }
            set { id = value; }

        }

        public string Nome
        {

            get { return nome; }
            set { nome = value; }

        }

        public string Email
        {

            get { return email; }
            set { email = value; }

        }

        public string Senha
        {

            get { return senha; }
            set { senha = value; }

        }


        public static bool verificarEmail(string email)
        {
            string emailValido = @"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$";
            Regex regex = new Regex(emailValido);
            return regex.IsMatch(email);
        }


        public static string CriptografarSenha(string senha)
        {
            try
            {
                using (SHA256 sha256Hash = SHA256.Create())
                {
                    byte[] bytes = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(senha));
                    StringBuilder builder = new StringBuilder();
                    for (int i = 0; i < bytes.Length; i++)
                    {
                        builder.Append(bytes[i].ToString("x2"));
                    }

                    return builder.ToString();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Não foi possível criptografar a senha: " + ex.Message, "Erro - Método Criptografar", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return "";
            }
        }


        public bool cadastrarUsuario()
        {

            try
            {

                using (MySqlConnection conexaoBanco = new ConexaoDB().Conectar())
                {

                    string senhaCriptografada = CriptografarSenha(Senha);


                    string insert = "INSERT INTO usuarios (nome, email, senha) VALUES (@nome, @email, @senha)";
                    MySqlCommand comandosql = new MySqlCommand(insert, conexaoBanco);

                    comandosql.Parameters.AddWithValue("@nome", Nome);
                    comandosql.Parameters.AddWithValue("@email", Email);
                    comandosql.Parameters.AddWithValue("@senha", senhaCriptografada);

                    int resultado = comandosql.ExecuteNonQuery();

                    if (resultado > 0)
                    {

                        return true;

                    }
                    else
                    {

                        return false;

                    }

                }

            }
            catch (Exception ex)
            {

                MessageBox.Show("Erro ao cadastrar -> " + ex.Message);
                return false;

            }

        } // fim cad usuario


        public bool verificarLogin()
        {

            try
            {

                using (MySqlConnection conexaoBanco = new ConexaoDB().Conectar())
                {

                    string senhaCriptografada = CriptografarSenha(Senha);

                    string consultaUsuarios = "SELECT COUNT(*) from usuarios WHERE email = @email and senha = @senha";

                    MySqlCommand comando = new MySqlCommand(consultaUsuarios, conexaoBanco);

                    comando.Parameters.AddWithValue("@email", Email);
                    comando.Parameters.AddWithValue("@senha", senhaCriptografada);

                    int result = Convert.ToInt32(comando.ExecuteScalar());

                    if (result > 0)
                    {

                        return true;

                    }
                    else
                    {

                        MessageBox.Show("Usuário não cadastrado");
                        return false;

                    }

                }

            }
            catch (Exception ex)
            {

                MessageBox.Show("Erro ao verificar login no banco -> " + ex.Message);
                return false;

            }

        }

        public string buscarNome()
        {

            try
            {

                using (MySqlConnection conexaoBanco = new ConexaoDB().Conectar())
                {

                    string senhaCriptografada = CriptografarSenha(Senha);

                    string selectNome = "SELECT nome from usuarios WHERE email = @email and senha = @senha";

                    MySqlCommand comando = new MySqlCommand(selectNome, conexaoBanco);

                    comando.Parameters.AddWithValue("@email", Email);
                    comando.Parameters.AddWithValue("@senha", senhaCriptografada);

                    object result = comando.ExecuteScalar();

                    if (result != null)
                    {

                        return result.ToString();

                    }
                    else
                    {

                        return "";

                    }

                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro!");
                return "";
            }

        }






    }
}

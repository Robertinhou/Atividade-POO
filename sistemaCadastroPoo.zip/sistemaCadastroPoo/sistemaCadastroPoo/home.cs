﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sistemaCadastroPoo
{
    public partial class home : Form
    {

        private string nomeUsuario;
        private Form telaLogin;

        public home(string nome, Form tela)
        {
            InitializeComponent();
            nomeUsuario = nome;
            telaLogin = tela;
        }

        private void lblNomeUser_Click(object sender, EventArgs e)
        {



        }

        private void home_Load(object sender, EventArgs e)
        {
            lblNomeUser.Text = "Bem vindo, " + nomeUsuario + "!";
        }

        private void home_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }
    }
}

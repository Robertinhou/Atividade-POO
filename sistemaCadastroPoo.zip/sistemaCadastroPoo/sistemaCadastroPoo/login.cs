
using MySql.Data.MySqlClient;

namespace sistemaCadastroPoo
{
    public partial class login : Form
    {

        private Form telaLog;
    
        public login()
        {
            

            InitializeComponent();
         

        }

        private void btnLogin_Click(object sender, EventArgs e)
        {

            try
            {


                if (!txtEmail.Text.Equals("") && !txtSenha.Text.Equals(""))
                {

                    Usuarios usuario = new Usuarios();

                    usuario.Email = txtEmail.Text;
                    usuario.Senha = txtSenha.Text;

                    if (Usuarios.verificarEmail(txtEmail.Text))
                    {

                        if (usuario.verificarLogin())
                        {



                            MessageBox.Show("Logado!");
                            string nomeLogado = usuario.buscarNome();
                            home home = new home(nomeLogado, this);

                            this.Hide();
                            home.Show();

                        }
                        else
                        {
                            MessageBox.Show("Usu�rio ou senha inv�lidos!");
                        }

                    }
                    else
                    {

                        MessageBox.Show("Email inv�lido!");

                    }


                }
                else
                {

                    MessageBox.Show("Preencha os campos corretamente!");

                }


            }
            catch (Exception ex)
            {

                MessageBox.Show("Erro ao logar -> " + ex.Message);

            }


        }

        private void checkSenha_CheckedChanged(object sender, EventArgs e)
        {

            txtSenha.PasswordChar = checkSenha.Checked ? '\0' : '�';

        }

        private void txtSenha_TextChanged(object sender, EventArgs e)
        {



        }

        private void linCadastro_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

            formCadastro cad = new formCadastro(this);

            cad.Show();
            this.Hide();

        }

        private void linkRecoverPwd_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

            forgotPassword forgot = new forgotPassword(this);

            forgot.Show();
            this.Hide();


        }
    }
}

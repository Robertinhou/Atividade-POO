﻿namespace sistemaCadastroPoo
{
    partial class forgotPassword
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            checkSenha = new CheckBox();
            linklogin = new LinkLabel();
            lblSenha = new Label();
            lblEmail = new Label();
            txtSenha = new TextBox();
            txtEmail = new TextBox();
            btnForgot = new Button();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(checkSenha);
            groupBox1.Controls.Add(linklogin);
            groupBox1.Controls.Add(lblSenha);
            groupBox1.Controls.Add(lblEmail);
            groupBox1.Controls.Add(txtSenha);
            groupBox1.Controls.Add(txtEmail);
            groupBox1.Controls.Add(btnForgot);
            groupBox1.Location = new Point(186, 78);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(429, 295);
            groupBox1.TabIndex = 11;
            groupBox1.TabStop = false;
            // 
            // checkSenha
            // 
            checkSenha.AutoSize = true;
            checkSenha.Location = new Point(179, 154);
            checkSenha.Name = "checkSenha";
            checkSenha.Size = new Size(88, 19);
            checkSenha.TabIndex = 12;
            checkSenha.Text = "Exibir senha";
            checkSenha.UseVisualStyleBackColor = true;
            // 
            // linklogin
            // 
            linklogin.AutoSize = true;
            linklogin.Location = new Point(179, 237);
            linklogin.Name = "linklogin";
            linklogin.Size = new Size(106, 15);
            linklogin.TabIndex = 10;
            linklogin.TabStop = true;
            linklogin.Text = "Voltar para o Login";
            linklogin.LinkClicked += linklogin_LinkClicked;
            // 
            // lblSenha
            // 
            lblSenha.AutoSize = true;
            lblSenha.Location = new Point(68, 106);
            lblSenha.Name = "lblSenha";
            lblSenha.Size = new Size(39, 15);
            lblSenha.TabIndex = 9;
            lblSenha.Text = "Senha";
            // 
            // lblEmail
            // 
            lblEmail.AutoSize = true;
            lblEmail.Location = new Point(68, 77);
            lblEmail.Name = "lblEmail";
            lblEmail.Size = new Size(36, 15);
            lblEmail.TabIndex = 8;
            lblEmail.Text = "Email";
            // 
            // txtSenha
            // 
            txtSenha.Location = new Point(113, 103);
            txtSenha.Name = "txtSenha";
            txtSenha.PasswordChar = '•';
            txtSenha.Size = new Size(224, 23);
            txtSenha.TabIndex = 7;
            // 
            // txtEmail
            // 
            txtEmail.Location = new Point(113, 74);
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(224, 23);
            txtEmail.TabIndex = 6;
            txtEmail.TextChanged += txtEmail_TextChanged;
            // 
            // btnForgot
            // 
            btnForgot.Location = new Point(119, 193);
            btnForgot.Name = "btnForgot";
            btnForgot.Size = new Size(218, 32);
            btnForgot.TabIndex = 5;
            btnForgot.Text = "Verificar";
            btnForgot.UseVisualStyleBackColor = true;
            btnForgot.Click += btnForgot_Click;
            // 
            // forgotPassword
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(groupBox1);
            Name = "forgotPassword";
            Text = "forgotPassword";
            FormClosing += forgotPassword_FormClosing;
            Load += forgotPassword_Load;
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private GroupBox groupBox1;
        private CheckBox checkSenha;
        private LinkLabel linklogin;
        private Label lblSenha;
        private Label lblEmail;
        private TextBox txtSenha;
        private TextBox txtEmail;
        private Button btnForgot;
    }
}
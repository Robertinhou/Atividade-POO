﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace sistemaCadastroPoo
{
    public class ConexaoDB
    {

        private string conexaoBanco = "Server=localHost;Database=sistemaCadastro;Uid=root;pwd=''";

        public MySqlConnection Conectar()
        {

            MySqlConnection conexao = new MySqlConnection(conexaoBanco);

            conexao.Open();

            return conexao;

        }

       

    }
}

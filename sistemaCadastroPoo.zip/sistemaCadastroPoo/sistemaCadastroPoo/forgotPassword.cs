﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sistemaCadastroPoo
{
    public partial class forgotPassword : Form
    {
        private Form telaForget;
        public forgotPassword(Form tela)
        {
            InitializeComponent();
            telaForget = tela;
        }

        private void forgotPassword_Load(object sender, EventArgs e)
        {

            checkSenha.Visible = false;
            txtSenha.Visible = false;
            lblSenha.Visible = false;



        }

        private void txtEmail_TextChanged(object sender, EventArgs e)
        {



        }

        private void btnForgot_Click(object sender, EventArgs e)
        {

            DialogResult result = MessageBox.Show("Redefinir senha?", "Email - Redefinição de senha", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {


                txtEmail.Visible = false;
                lblEmail.Visible = false;

                checkSenha.Visible = true;
                lblSenha.Visible = true;
                txtSenha.Visible = true;



            }
           


        }

        private void forgotPassword_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void linklogin_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

            login log = new login(this);
            this.Hide();
            log.Show();

        }
    }
}

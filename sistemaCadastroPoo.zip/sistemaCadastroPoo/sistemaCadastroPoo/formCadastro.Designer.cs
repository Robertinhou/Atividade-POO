﻿namespace sistemaCadastroPoo
{
    partial class formCadastro
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnCadastro = new Button();
            groupBox1 = new GroupBox();
            linkLogin = new LinkLabel();
            lblNome = new Label();
            txtNome = new TextBox();
            lblSenha = new Label();
            lblEmail = new Label();
            txtSenha = new TextBox();
            txtEmail = new TextBox();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // btnCadastro
            // 
            btnCadastro.Location = new Point(138, 194);
            btnCadastro.Name = "btnCadastro";
            btnCadastro.Size = new Size(218, 32);
            btnCadastro.TabIndex = 0;
            btnCadastro.Text = "Cadastro";
            btnCadastro.UseVisualStyleBackColor = true;
            btnCadastro.Click += btnCadastro_Click;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(linkLogin);
            groupBox1.Controls.Add(lblNome);
            groupBox1.Controls.Add(txtNome);
            groupBox1.Controls.Add(lblSenha);
            groupBox1.Controls.Add(lblEmail);
            groupBox1.Controls.Add(txtSenha);
            groupBox1.Controls.Add(txtEmail);
            groupBox1.Controls.Add(btnCadastro);
            groupBox1.Location = new Point(157, 68);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(498, 284);
            groupBox1.TabIndex = 1;
            groupBox1.TabStop = false;
            // 
            // linkLogin
            // 
            linkLogin.AutoSize = true;
            linkLogin.Font = new Font("Segoe UI", 10F);
            linkLogin.Location = new Point(182, 251);
            linkLogin.Name = "linkLogin";
            linkLogin.Size = new Size(126, 19);
            linkLogin.TabIndex = 7;
            linkLogin.TabStop = true;
            linkLogin.Text = "Já possuí cadastro?";
            linkLogin.LinkClicked += linkLogin_LinkClicked;
            // 
            // lblNome
            // 
            lblNome.AutoSize = true;
            lblNome.Location = new Point(91, 47);
            lblNome.Name = "lblNome";
            lblNome.Size = new Size(40, 15);
            lblNome.TabIndex = 6;
            lblNome.Text = "Nome";
            // 
            // txtNome
            // 
            txtNome.Location = new Point(136, 44);
            txtNome.Name = "txtNome";
            txtNome.Size = new Size(224, 23);
            txtNome.TabIndex = 5;
            // 
            // lblSenha
            // 
            lblSenha.AutoSize = true;
            lblSenha.Location = new Point(91, 144);
            lblSenha.Name = "lblSenha";
            lblSenha.Size = new Size(39, 15);
            lblSenha.TabIndex = 4;
            lblSenha.Text = "Senha";
            lblSenha.Click += lblSenha_Click;
            // 
            // lblEmail
            // 
            lblEmail.AutoSize = true;
            lblEmail.Location = new Point(91, 93);
            lblEmail.Name = "lblEmail";
            lblEmail.Size = new Size(36, 15);
            lblEmail.TabIndex = 3;
            lblEmail.Text = "Email";
            // 
            // txtSenha
            // 
            txtSenha.Location = new Point(136, 141);
            txtSenha.Name = "txtSenha";
            txtSenha.Size = new Size(224, 23);
            txtSenha.TabIndex = 2;
            // 
            // txtEmail
            // 
            txtEmail.Location = new Point(136, 90);
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(224, 23);
            txtEmail.TabIndex = 1;
            // 
            // formCadastro
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(groupBox1);
            Name = "formCadastro";
            Text = "cadastro";
            FormClosing += formCadastro_FormClosing;
            Load += cadastro_Load;
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Button btnCadastro;
        private GroupBox groupBox1;
        private Label lblEmail;
        private TextBox txtSenha;
        private TextBox txtEmail;
        private Label lblSenha;
        private Label lblNome;
        private TextBox txtNome;
        private LinkLabel linkLogin;
    }
}